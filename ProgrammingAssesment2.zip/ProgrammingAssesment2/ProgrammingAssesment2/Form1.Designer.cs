﻿namespace ProgrammingAssesment2
{
    partial class VideoGamesLibrary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VideoGamesLibrary));
            this.GamesListBox = new System.Windows.Forms.ListBox();
            this.AddButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.LoadButton = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.RatingContainer = new System.Windows.Forms.GroupBox();
            this.RadioX = new System.Windows.Forms.RadioButton();
            this.RadioR = new System.Windows.Forms.RadioButton();
            this.RadioMA = new System.Windows.Forms.RadioButton();
            this.RadioM = new System.Windows.Forms.RadioButton();
            this.RadioPG = new System.Windows.Forms.RadioButton();
            this.RadioG = new System.Windows.Forms.RadioButton();
            this.NameLabel = new System.Windows.Forms.Label();
            this.PlatformLabel = new System.Windows.Forms.Label();
            this.GenreLabel = new System.Windows.Forms.Label();
            this.NameInput = new System.Windows.Forms.TextBox();
            this.DevInput = new System.Windows.Forms.TextBox();
            this.PriceLabel = new System.Windows.Forms.Label();
            this.DevLabel = new System.Windows.Forms.Label();
            this.PlatformSelect = new System.Windows.Forms.ComboBox();
            this.GenreSelect = new System.Windows.Forms.ComboBox();
            this.GamesListLabel = new System.Windows.Forms.Label();
            this.RemoveButton = new System.Windows.Forms.Button();
            this.ToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ClearButton = new System.Windows.Forms.Button();
            this.PriceInput = new System.Windows.Forms.MaskedTextBox();
            this.RatingContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // GamesListBox
            // 
            this.GamesListBox.FormattingEnabled = true;
            this.GamesListBox.Location = new System.Drawing.Point(233, 108);
            this.GamesListBox.Name = "GamesListBox";
            this.GamesListBox.Size = new System.Drawing.Size(172, 264);
            this.GamesListBox.TabIndex = 27;
            this.GamesListBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.GamesListBox_MouseClick);
            // 
            // AddButton
            // 
            this.AddButton.Location = new System.Drawing.Point(31, 291);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(75, 23);
            this.AddButton.TabIndex = 21;
            this.AddButton.Text = "Add";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            this.AddButton.MouseHover += new System.EventHandler(this.AddButton_MouseHover);
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(31, 320);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 23;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            this.SaveButton.MouseHover += new System.EventHandler(this.SaveButton_MouseHover);
            // 
            // LoadButton
            // 
            this.LoadButton.Location = new System.Drawing.Point(31, 349);
            this.LoadButton.Name = "LoadButton";
            this.LoadButton.Size = new System.Drawing.Size(75, 23);
            this.LoadButton.TabIndex = 25;
            this.LoadButton.Text = "Load";
            this.LoadButton.UseVisualStyleBackColor = true;
            this.LoadButton.Click += new System.EventHandler(this.LoadButton_Click);
            this.LoadButton.MouseHover += new System.EventHandler(this.LoadButton_MouseHover);
            // 
            // UpdateButton
            // 
            this.UpdateButton.Location = new System.Drawing.Point(125, 320);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(75, 23);
            this.UpdateButton.TabIndex = 24;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            this.UpdateButton.MouseHover += new System.EventHandler(this.UpdateButton_MouseHover);
            // 
            // RatingContainer
            // 
            this.RatingContainer.Controls.Add(this.RadioX);
            this.RatingContainer.Controls.Add(this.RadioR);
            this.RatingContainer.Controls.Add(this.RadioMA);
            this.RatingContainer.Controls.Add(this.RadioM);
            this.RatingContainer.Controls.Add(this.RadioPG);
            this.RatingContainer.Controls.Add(this.RadioG);
            this.RatingContainer.Location = new System.Drawing.Point(31, 104);
            this.RatingContainer.Name = "RatingContainer";
            this.RatingContainer.Size = new System.Drawing.Size(169, 172);
            this.RatingContainer.TabIndex = 15;
            this.RatingContainer.TabStop = false;
            this.RatingContainer.Text = "Rating";
            // 
            // RadioX
            // 
            this.RadioX.AutoSize = true;
            this.RadioX.Location = new System.Drawing.Point(7, 140);
            this.RadioX.Name = "RadioX";
            this.RadioX.Size = new System.Drawing.Size(89, 17);
            this.RadioX.TabIndex = 6;
            this.RadioX.TabStop = true;
            this.RadioX.Text = "Restricted (X)";
            this.RadioX.UseVisualStyleBackColor = true;
            // 
            // RadioR
            // 
            this.RadioR.AutoSize = true;
            this.RadioR.Location = new System.Drawing.Point(7, 116);
            this.RadioR.Name = "RadioR";
            this.RadioR.Size = new System.Drawing.Size(90, 17);
            this.RadioR.TabIndex = 5;
            this.RadioR.TabStop = true;
            this.RadioR.Text = "Restricted (R)";
            this.RadioR.UseVisualStyleBackColor = true;
            // 
            // RadioMA
            // 
            this.RadioMA.AutoSize = true;
            this.RadioMA.Location = new System.Drawing.Point(7, 92);
            this.RadioMA.Name = "RadioMA";
            this.RadioMA.Size = new System.Drawing.Size(136, 17);
            this.RadioMA.TabIndex = 4;
            this.RadioMA.TabStop = true;
            this.RadioMA.Text = "Mature Audiences (MA)";
            this.RadioMA.UseVisualStyleBackColor = true;
            // 
            // RadioM
            // 
            this.RadioM.AutoSize = true;
            this.RadioM.Location = new System.Drawing.Point(7, 68);
            this.RadioM.Name = "RadioM";
            this.RadioM.Size = new System.Drawing.Size(76, 17);
            this.RadioM.TabIndex = 3;
            this.RadioM.TabStop = true;
            this.RadioM.Text = "Mature (M)";
            this.RadioM.UseVisualStyleBackColor = true;
            // 
            // RadioPG
            // 
            this.RadioPG.AutoSize = true;
            this.RadioPG.Location = new System.Drawing.Point(7, 44);
            this.RadioPG.Name = "RadioPG";
            this.RadioPG.Size = new System.Drawing.Size(137, 17);
            this.RadioPG.TabIndex = 2;
            this.RadioPG.TabStop = true;
            this.RadioPG.Text = "Parental Guidance (PG)";
            this.RadioPG.UseVisualStyleBackColor = true;
            // 
            // RadioG
            // 
            this.RadioG.AutoSize = true;
            this.RadioG.Location = new System.Drawing.Point(7, 20);
            this.RadioG.Name = "RadioG";
            this.RadioG.Size = new System.Drawing.Size(79, 17);
            this.RadioG.TabIndex = 1;
            this.RadioG.TabStop = true;
            this.RadioG.Text = "General (G)";
            this.RadioG.UseVisualStyleBackColor = true;
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(38, 16);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(35, 13);
            this.NameLabel.TabIndex = 7;
            this.NameLabel.Text = "Name";
            // 
            // PlatformLabel
            // 
            this.PlatformLabel.AutoSize = true;
            this.PlatformLabel.Location = new System.Drawing.Point(29, 46);
            this.PlatformLabel.Name = "PlatformLabel";
            this.PlatformLabel.Size = new System.Drawing.Size(45, 13);
            this.PlatformLabel.TabIndex = 8;
            this.PlatformLabel.Text = "Platform";
            // 
            // GenreLabel
            // 
            this.GenreLabel.AutoSize = true;
            this.GenreLabel.Location = new System.Drawing.Point(38, 74);
            this.GenreLabel.Name = "GenreLabel";
            this.GenreLabel.Size = new System.Drawing.Size(36, 13);
            this.GenreLabel.TabIndex = 9;
            this.GenreLabel.Text = "Genre";
            // 
            // NameInput
            // 
            this.NameInput.Location = new System.Drawing.Point(77, 16);
            this.NameInput.Name = "NameInput";
            this.NameInput.Size = new System.Drawing.Size(121, 20);
            this.NameInput.TabIndex = 10;
            // 
            // DevInput
            // 
            this.DevInput.Location = new System.Drawing.Point(288, 43);
            this.DevInput.Name = "DevInput";
            this.DevInput.Size = new System.Drawing.Size(117, 20);
            this.DevInput.TabIndex = 13;
            // 
            // PriceLabel
            // 
            this.PriceLabel.AutoSize = true;
            this.PriceLabel.Location = new System.Drawing.Point(215, 16);
            this.PriceLabel.Name = "PriceLabel";
            this.PriceLabel.Size = new System.Drawing.Size(71, 13);
            this.PriceLabel.TabIndex = 13;
            this.PriceLabel.Text = "Price (AUS) $";
            // 
            // DevLabel
            // 
            this.DevLabel.AutoSize = true;
            this.DevLabel.Location = new System.Drawing.Point(230, 46);
            this.DevLabel.Name = "DevLabel";
            this.DevLabel.Size = new System.Drawing.Size(56, 13);
            this.DevLabel.TabIndex = 14;
            this.DevLabel.Text = "Developer";
            // 
            // PlatformSelect
            // 
            this.PlatformSelect.FormattingEnabled = true;
            this.PlatformSelect.Items.AddRange(new object[] {
            "PC",
            "Mac",
            "Xbone",
            "Xbox 360",
            "Xbox",
            "PS4",
            "PS3",
            "PS2",
            "PS1",
            "PSVita",
            "PSP",
            "Switch",
            "Wii U",
            "Wii",
            "GameCube",
            "3DS",
            "DS",
            "iPhone"});
            this.PlatformSelect.Location = new System.Drawing.Point(77, 43);
            this.PlatformSelect.Name = "PlatformSelect";
            this.PlatformSelect.Size = new System.Drawing.Size(121, 21);
            this.PlatformSelect.TabIndex = 12;
            // 
            // GenreSelect
            // 
            this.GenreSelect.FormattingEnabled = true;
            this.GenreSelect.Items.AddRange(new object[] {
            "Action",
            "Adventure",
            "Kids",
            "Puzzle",
            "Racing",
            "RPG",
            "Shooting",
            "Simulation",
            "Strategy",
            "Sport"});
            this.GenreSelect.Location = new System.Drawing.Point(77, 74);
            this.GenreSelect.Name = "GenreSelect";
            this.GenreSelect.Size = new System.Drawing.Size(121, 21);
            this.GenreSelect.TabIndex = 14;
            // 
            // GamesListLabel
            // 
            this.GamesListLabel.AutoSize = true;
            this.GamesListLabel.Location = new System.Drawing.Point(296, 92);
            this.GamesListLabel.Name = "GamesListLabel";
            this.GamesListLabel.Size = new System.Drawing.Size(59, 13);
            this.GamesListLabel.TabIndex = 17;
            this.GamesListLabel.Text = "Games List";
            // 
            // RemoveButton
            // 
            this.RemoveButton.Location = new System.Drawing.Point(125, 291);
            this.RemoveButton.Name = "RemoveButton";
            this.RemoveButton.Size = new System.Drawing.Size(75, 23);
            this.RemoveButton.TabIndex = 22;
            this.RemoveButton.Text = "Remove";
            this.RemoveButton.UseVisualStyleBackColor = true;
            this.RemoveButton.Click += new System.EventHandler(this.RemoveButton_Click);
            this.RemoveButton.MouseHover += new System.EventHandler(this.RemoveButton_MouseHover);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(125, 349);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(75, 23);
            this.ClearButton.TabIndex = 26;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            this.ClearButton.MouseHover += new System.EventHandler(this.ClearButton_MouseHover);
            // 
            // PriceInput
            // 
            this.PriceInput.Location = new System.Drawing.Point(288, 12);
            this.PriceInput.Mask = "00000";
            this.PriceInput.Name = "PriceInput";
            this.PriceInput.Size = new System.Drawing.Size(37, 20);
            this.PriceInput.TabIndex = 11;
            // 
            // VideoGamesLibrary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 388);
            this.Controls.Add(this.PriceInput);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.RemoveButton);
            this.Controls.Add(this.GamesListLabel);
            this.Controls.Add(this.GenreSelect);
            this.Controls.Add(this.PlatformSelect);
            this.Controls.Add(this.DevLabel);
            this.Controls.Add(this.PriceLabel);
            this.Controls.Add(this.DevInput);
            this.Controls.Add(this.NameInput);
            this.Controls.Add(this.GenreLabel);
            this.Controls.Add(this.PlatformLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.RatingContainer);
            this.Controls.Add(this.UpdateButton);
            this.Controls.Add(this.LoadButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.GamesListBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "VideoGamesLibrary";
            this.Text = "Video Games Library";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.VideoGamesLibrary_FormClosed);
            this.RatingContainer.ResumeLayout(false);
            this.RatingContainer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox GamesListBox;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button LoadButton;
        private System.Windows.Forms.Button UpdateButton;
        private System.Windows.Forms.GroupBox RatingContainer;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label PlatformLabel;
        private System.Windows.Forms.Label GenreLabel;
        private System.Windows.Forms.TextBox NameInput;
        private System.Windows.Forms.TextBox DevInput;
        private System.Windows.Forms.Label PriceLabel;
        private System.Windows.Forms.Label DevLabel;
        private System.Windows.Forms.RadioButton RadioX;
        private System.Windows.Forms.RadioButton RadioR;
        private System.Windows.Forms.RadioButton RadioMA;
        private System.Windows.Forms.RadioButton RadioM;
        private System.Windows.Forms.RadioButton RadioPG;
        private System.Windows.Forms.RadioButton RadioG;
        private System.Windows.Forms.ComboBox PlatformSelect;
        private System.Windows.Forms.ComboBox GenreSelect;
        private System.Windows.Forms.Label GamesListLabel;
        private System.Windows.Forms.Button RemoveButton;
        private System.Windows.Forms.ToolTip ToolTip;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.MaskedTextBox PriceInput;
    }
}

