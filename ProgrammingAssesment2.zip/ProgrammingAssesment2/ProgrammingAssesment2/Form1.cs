﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ProgrammingAssesment2
{
    public partial class VideoGamesLibrary : Form
    {
        public VideoGamesLibrary()
        {
            InitializeComponent();
        }

        List<game> MyGames = new List<game>();

        private void AddButton_Click(object sender, EventArgs e)
        {
            bool hasData = true; // Used to mark if all boxes are valid to save
            game g = new game(); // Temporary object to hold form values
            g.Name = NameInput.Text; // Add value to temporary object
            if (String.IsNullOrEmpty(NameInput.Text))
            {
                MessageBox.Show("Please enter Game Name");
                hasData = false;
                return;
            }
            g.Platform = PlatformSelect.Text;
            if (String.IsNullOrEmpty(PlatformSelect.Text))
            {
                MessageBox.Show("Please enter Platform Type");
                hasData = false;
                return;
            }
            g.Genre = GenreSelect.Text;
            if (String.IsNullOrEmpty(GenreSelect.Text))
            {
                MessageBox.Show("Please enter Genre");
                hasData = false;
                return;
            }
            g.Price = PriceInput.Text;
            if (String.IsNullOrEmpty(PriceInput.Text))
            {
                MessageBox.Show("Please enter Price");
                hasData = false;
                return;
            }
            g.Developer = DevInput.Text;
            if (String.IsNullOrEmpty(DevInput.Text))
            {
                MessageBox.Show("Please enter Developer Name");
                hasData = false;
                return;
            }
            g.Rating = ratingType();
            if (ratingType() == null)
            {
                MessageBox.Show("Please enter Rating");
                hasData = false;
                return;
            }

            bool duplicateFound = MyGames.Exists(x => x.Name == NameInput.Text);
            if (hasData && !duplicateFound)
            {
                MyGames.Add(g); // Add all temporary fields to List<>
                clearFields(); // Clear form fields
                
                displayfields();
            }
            else
            {
                MessageBox.Show("Duplicate Game found");
            }
        } // End of Add Button

        private void SaveButton_Click(object sender, EventArgs e)
        {
            WriteToXmlFile<List<game>>("C:\\Temp\\GameLibrary.xml", MyGames);
            MessageBox.Show("All records Saved", "Save and Close", MessageBoxButtons.OK);
        } // End of Save Button

        private void LoadButton_Click(object sender, EventArgs e)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            // Test to see if temp folder is there
            if (!Directory.Exists("C:\\Temp"))
                // if not, it creates the folder
                Directory.CreateDirectory("C:\\Temp");
            // Test to see if XML file is there
            if (!File.Exists("C:\\Temp\\GameLibrary.xml"))
                // if not, it creates the file
                File.Create("C:\\Temp\\GameLibrary.xml").Close();
            // Call method to read data from XML to List<>
            try
            {
                MyGames = ReadFromXmlFile<List<game>>("C:\\Temp\\GameLibrary.xml");
                displayfields();
            } catch (Exception exc)
            {
                MessageBox.Show("Nothing to load");
            }
        } // End of Load Button

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            game updateGame = new game();
            updateGame.Name = NameInput.Text; // Overwrite Stored values
            updateGame.Platform = PlatformSelect.Text;
            updateGame.Genre = GenreSelect.Text;
            updateGame.Price = PriceInput.Text;
            updateGame.Developer = DevInput.Text;
            updateGame.Rating = ratingType();
            if (GamesListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Select a Game from the list to update");
            }
            else
            {
                // Get value of currently selected item in listbox
                string curItem = GamesListBox.SelectedItem.ToString();
                // Find item in listbox to change values of, through selected item value
                int indx = GamesListBox.FindString(curItem);
                MyGames[indx].Name = updateGame.Name;
                MyGames[indx].Platform = updateGame.Platform;
                MyGames[indx].Genre = updateGame.Genre;
                MyGames[indx].Price = updateGame.Price;
                MyGames[indx].Developer = updateGame.Developer;
                MyGames[indx].Rating = updateGame.Rating;
                clearFields(); // Clear form fields
                displayfields(); // Display list items
            }
        } // End of Update Button

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            if (GamesListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Select a Game from the list to remove");
            }
            else
            {
                // Get value of currently selected item in listbox
                string curItem = GamesListBox.SelectedItem.ToString();
                // Find item in listbox to change values of, through selected item value
                int indx = GamesListBox.FindString(curItem);
                MyGames.RemoveAt(indx); // Remove item from list
                clearFields(); // Clear form fields
                displayfields();
            }
        }// End of Remove Button

        private void ClearButton_Click(object sender, EventArgs e)
        {
            clearFields();
        }// End of Clear Button

        private void GamesListBox_MouseClick(object sender, MouseEventArgs e)
        {
            // if ListBox index is valid then display all form fields
            if (GamesListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Item is not available in Games list");
            }
            else
            {
                // Get value of currently selected item in listbox
                string curItem = GamesListBox.SelectedItem.ToString();
                // Find item in listbox to change values of, through selected item value
                int indx = GamesListBox.FindString(curItem);
                GamesListBox.SetSelected(indx, true);
                NameInput.Text = MyGames[indx].Name;
                PlatformSelect.Text = MyGames[indx].Platform;
                GenreSelect.Text = MyGames[indx].Genre;
                PriceInput.Text = MyGames[indx].Price;
                DevInput.Text = MyGames[indx].Developer;
                foreach (RadioButton rad in RatingContainer.Controls)
                {
                    if (rad.Text == MyGames[indx].Rating)
                    {
                        rad.Checked = true;
                    }
                }
            }
        }// End of list item selector

        // Find selected radio button
        public String ratingType()
        {
            foreach (RadioButton rad in RatingContainer.Controls)
            {
                if (rad.Checked == true)
                {
                    String ratingText = rad.Text;
                    return ratingText;
                }
            }
            return null;
        }// End of ratingType finder

        // Display Fields
        public void displayfields()
        {
            GamesListBox.Items.Clear();
            MyGames.Sort();
            foreach (var x in MyGames)
            {
                GamesListBox.Items.Add(x.Name + " : " + x.Platform);
            }
        }// End of DisplayFields

        // Clear Fields
        private void clearFields()
        {
            NameInput.Text = "";
            PlatformSelect.Text = "";
            GenreSelect.Text = "";
            PriceInput.Text = "";
            DevInput.Text = "";
            foreach (RadioButton rad in RatingContainer.Controls)
            {
                rad.Checked = false;
            }


        }// End of ClearFields

        // Write to XML File
        public static void WriteToXmlFile<T>(string filePath, T objectToWrite, bool append = false) where T : new()
        {
            TextWriter writer = null;
            try
            {
                var serializer = new XmlSerializer(typeof(T));
                writer = new StreamWriter(filePath, append);
                serializer.Serialize(writer, objectToWrite);
            }
            finally
            {
                if (writer != null)
                    writer.Close();
            }

        }// End of WriteToXmlFile

        //Read From XML File
        public static T ReadFromXmlFile<T>(string filePath) where T : new()
        {
            TextReader reader = null;
            try
            {
                var serializer = new XmlSerializer(typeof(T));
                reader = new StreamReader(filePath);
                return (T)serializer.Deserialize(reader);
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }

        }// End of ReadFromXMLFile

        private void VideoGamesLibrary_FormClosed(object sender, FormClosedEventArgs e)
        {
            WriteToXmlFile<List<game>>("C:\\Temp\\GameLibrary.xml", MyGames);
            MessageBox.Show("All records Saved", "Save and Close", MessageBoxButtons.OK);
            Application.Exit();
        }

        private void AddButton_MouseHover(object sender, EventArgs e)
        {
            ToolTip.Show("Adds game to library", AddButton);// Show a tool tip when button is being hovered over
        }

        private void RemoveButton_MouseHover(object sender, EventArgs e)
        {
            ToolTip.Show("Removes selected game from library", RemoveButton);
        }

        private void SaveButton_MouseHover(object sender, EventArgs e)
        {
            ToolTip.Show("Saves library to file", SaveButton);
        }

        private void UpdateButton_MouseHover(object sender, EventArgs e)
        {
            ToolTip.Show("Updates selected game on library", UpdateButton);
        }

        private void LoadButton_MouseHover(object sender, EventArgs e)
        {
            ToolTip.Show("Loads library from file", LoadButton);
        }

        private void ClearButton_MouseHover(object sender, EventArgs e)
        {
            ToolTip.Show("Clears fields on form", LoadButton);
        }

    } // End of Video Games Library

    public class game : IComparable<game>
    {
        [XmlElement("Name")]
        public string Name
        {
            get;
            set;
        }
        [XmlElement("Platform")]
        public string Platform
        {
            get;
            set;
        }
        [XmlElement("Genre")]
        public string Genre
        {
            get;
            set;
        }
        [XmlElement("Price")]
        public string Price
        {
            get;
            set;
        }
        [XmlElement("Developer")]
        public string Developer
        {
            get;
            set;
        }
        [XmlElement("Rating")]
        public string Rating
        {
            get;
            set;
        }

        // Sort by Name
        public int CompareTo(game other)
        {
            return this.Name.CompareTo(other.Name);
        }
    }
}